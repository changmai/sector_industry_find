# REST[주식] 상위종목
> 원본 URL: https://openapi.ls-sec.co.kr/apiservice?group_id=73142d9f-1983-48d2-8543-89b75535d34c&api_id=d3d0ef41-6a0f-4bda-9e28-160071f66206

## 📌 기본 정보
| 항목           | 내용                                       |
|:-------------|:-----------------------------------------|
| Method       | POST                                     |
| Domain       | https://openapi.ls-sec.co.kr:8080        |
| 운영 도메인       | https://openapi.ls-sec.co.kr:8080        |
| 모의투자 도메인     |                                          |
| URL          | /stock/high-item                         |
| Format       | JSON                                     |
| Content-Type | application/json; charset=UTF-8          |
| Description  | 거래대금 및 등락율 등 항목별 상위데이터를 확인할 수 있는 서비스입니다. |


## 🏷️ 등락율상위 (t1441)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                                                                                                                                                                                                                                                                                                   |
|:-------------|:-------------|:-------|:-----------|:---------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| t1441InBlock | t1441InBlock | Object | Y          | -        |                                                                                                                                                                                                                                                                                                               |
| -gubun1      | 구분           | String | Y          | 1        | 0:전체1:코스피2:코스닥                                                                                                                                                                                                                                                                                                |
| -gubun2      | 상승하락         | String | Y          | 1        | 0: 상승률1: 하락률2: 보합                                                                                                                                                                                                                                                                                             |
| -gubun3      | 당일전일         | String | Y          | 1        | 0: 당일1: 전일                                                                                                                                                                                                                                                                                                    |
| -jc_num      | 대상제외         | Number | Y          | 12       | 대상제외값증거금50 : 0x00400000증거금100 : 0x00800000증거금50/100 : 0x00200000관리종목 : 0x00000080시장경보 : 0x00000100거래정지 : 0x00000200우선주 : 0x00004000투자유의 : 0x04000000정리매매 : 0x01000000불성실공시 : 0x80000000                                                                                                                       |
| -sprice      | 시작가격         | Number | Y          | 8        | 현재가 >= sprice                                                                                                                                                                                                                                                                                                 |
| -eprice      | 종료가격         | Number | Y          | 8        | 현재가 <= eprice                                                                                                                                                                                                                                                                                                 |
| -volume      | 거래량          | Number | Y          | 12       | 거래량 >= volume                                                                                                                                                                                                                                                                                                 |
| -idx         | IDX          | Number | Y          | 4        | 처음 조회시는 Space연속 조회시에 이전 조회한 OutBlock의 idx 값으로 설정                                                                                                                                                                                                                                                              |
| -jc_num2     | 대상제외2        | Number | Y          | 12       | 기본         => 000000000000상장지수펀드 => 000000000001선박투자회사 => 000000000002스펙         => 000000000004ETN          => 000000000008(0x00000008)투자주의     => 000000000016(0x00000010)투자위험     => 000000000032(0x00000020)위험예고     => 000000000064(0x00000040)담보불가     => 000000000128(0x00000080)두개 이상 제외시 해당 값을 합산한다. |
| -exchgubun   | 거래소구분코드      | String | Y          | 1        | K: KRXN: NXTU:통합그외 입력값은 KRX로 처리                                                                                                                                                                                                                                                                               |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1441OutBlock  | t1441OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1441OutBlock1 | t1441OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 한글명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -offerrem1     | 매도잔량           | Number       | Y          | 12       |               |
| -offerho1      | 매도호가           | Number       | Y          | 12       |               |
| -bidho1        | 매수호가           | Number       | Y          | 12       |               |
| -bidrem1       | 매수잔량           | Number       | Y          | 12       |               |
| -updaycnt      | 연속             | Number       | Y          | 4        |               |
| -jnildiff      | 전일등락율          | Number       | Y          | 6.2      |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -open          | 시가             | Number       | Y          | 8        |               |
| -high          | 고가             | Number       | Y          | 8        |               |
| -low           | 저가             | Number       | Y          | 8        |               |
| -voldiff       | 거래량대비율         | Number       | Y          | 8.2      |               |
| -value         | 거래대금           | Number       | Y          | 15       |               |
| -total         | 시가총액           | Number       | Y          | 12       |               |
| -ex_shcode     | 거래소별단축코드       | String       | Y          | 10       |               |


### 💡 Request Example
```json
{
  "t1441InBlock" : {
    "gubun1" : "1",
    "gubun2" : "1",
    "gubun3" : "1",
    "jc_num" : 0,
    "sprice" : 0,
    "eprice" : 0,
    "volume" : 0,
    "idx" : 0,
    "jc_num2" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1441OutBlock1": [
        {
            "change": 20,
            "offerrem1": 2780,
            "shcode": "119650",
            "sign": "5",
            "diff": "-00.70",
            "volume": 514736,
            "bidrem1": 1307,
            "high": 2890,
            "voldiff": "00011.86",
            "total": 1027,
            "low": 2760,
            "price": 2845,
            "jnildiff": "-12.39",
            "bidho1": 2840,
            "value": 1449,
            "hname": "KC코트렐",
            "open": 2870,
            "offerho1": 2845,
            "updaycnt": 2
        },
        {
            "change": 0,
            "offerrem1": 5203059,
            "shcode": "550043",
            "sign": "3",
            "diff": "000.00",
            "volume": 671167,
            "bidrem1": 606185,
            "high": 120,
            "voldiff": "00384.24",
            "total": 180,
            "low": 115,
            "price": 120,
            "jnildiff": "-07.69",
            "bidho1": 115,
            "value": 78,
            "hname": "QV 인버스 레버리지 W",
            "open": 115,
            "offerho1": 120,
            "updaycnt": 0
        }
    ],
    "t1441OutBlock": {
        "idx": 20
    },
    "rsp_msg": "조회완료"
}

```

---

## 🏷️ 시가총액상위 (t1444)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                        |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------------------|
| t1444InBlock | t1444InBlock | Object | Y          | -        |                                    |
| -upcode      | 업종코드         | String | Y          | 3        |                                    |
| -idx         | IDX          | Number | Y          | 4        | 처음 조회시 Space                       |
|              |              |        |            |          | 연속 조회시 이전 조회한 OutBlock의 idx 값으로 설정 |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1444OutBlock  | t1444OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1444OutBlock1 | t1444OutBlock1 | Object Array | Y          | -        |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -hname         | 종목명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 거래량            | Number       | Y          | 12       |               |
| -vol_rate      | 거래비중           | Number       | Y          | 6.2      |               |
| -total         | 시가총액           | Number       | Y          | 12       |               |
| -rate          | 비중             | Number       | Y          | 6.2      |               |
| -for_rate      | 외인비중           | Number       | Y          | 6.2      |               |


### 💡 Request Example
```json
{
  "t1444InBlock" : {
    "upcode" : "001",
    "idx" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1444OutBlock1": [
        {
            "volume": 4817941,
            "total": 4280334,
            "for_rate": "52.54",
            "vol_rate": "1.26",
            "rate": "19.67",
            "price": 71700,
            "shcode": "005930",
            "change": 500,
            "sign": "5",
            "diff": "-0.69",
            "hname": "삼성전자"
        },
        {
            "volume": 223627,
            "total": 183174,
            "for_rate": "24.66",
            "vol_rate": "0.06",
            "rate": "0.84",
            "price": 198100,
            "shcode": "096770",
            "change": 100,
            "sign": "2",
            "diff": "0.05",
            "hname": "SK이노베이션"
        }
    ],
    "t1444OutBlock": {
        "idx": 20
    },
    "rsp_msg": "조회완료"
}

```

---

## 🏷️ 거래량상위 (t1452)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                                                |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------------------------------------------|
| t1452InBlock | t1452InBlock | Object | Y          | -        |                                                            |
| -gubun       | 구분           | String | Y          | 1        | 0:전체                                                       |
|              |              |        |            |          | 1:코스피                                                      |
|              |              |        |            |          | 2:코스닥                                                      |
| -jnilgubun   | 전일구분         | String | Y          | 1        | 1:당일                                                       |
|              |              |        |            |          | 2:전일                                                       |
| -sdiff       | 시작등락율        | Number | Y          | 3        | 현재등락율 >= sdiff                                             |
| -ediff       | 종료등락율        | Number | Y          | 3        | 현재등락율 <= ediff                                             |
| -jc_num      | 대상제외         | Number | Y          | 12       | 대상제외값                                                      |
|              |              |        |            |          | (0x00000080)관리종목  => 000000000128                          |
|              |              |        |            |          | (0x00000100)시장경보  => 000000000256                          |
|              |              |        |            |          | (0x00000200)거래정지  => 000000000512                          |
|              |              |        |            |          | (0x00004000)우선주  => 000000016384                           |
|              |              |        |            |          | (0x00200000)증거금50  => 000008388608                         |
|              |              |        |            |          | (0x01000000)정리매매  => 000016777216                          |
|              |              |        |            |          | (0x04000000)투자유의  => 000067108864                          |
|              |              |        |            |          | (0x80000000)불성실공시  => -02147483648                         |
|              |              |        |            |          | 두개 이상 제외시 해당 값을 합산한다                                       |
|              |              |        |            |          | 예)관리종목 + 시장경보 = 000000000128 + 000000000256 = 000000000384 |
| -sprice      | 시작가격         | Number | Y          | 8        | 현재가 >= sprice                                              |
| -eprice      | 종료가격         | Number | Y          | 8        | 현재가 <= eprice                                              |
| -volume      | 거래량          | Number | Y          | 12       | 거래량 >= volume                                              |
| -idx         | IDX          | Number | Y          | 4        | 처음 조회시는 Space                                              |
|              |              |        |            |          | 연속 조회시에 이전 조회한 OutBlock의 idx 값으로 설정                        |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1452OutBlock  | t1452OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1452OutBlock1 | t1452OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 종목명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -vol           | 회전율            | Number       | Y          | 6.2      |               |
| -jnilvolume    | 전일거래량          | Number       | Y          | 12       |               |
| -bef_diff      | 전일비            | Number       | Y          | 10.2     |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |


### 💡 Request Example
```json
{
   "t1452InBlock" :{
      "gubun" : "1",
      "jnilgubun" : "1",
      "sdiff" : 0,
      "ediff" : 0,
      "jc_num" : 0,
      "sprice" : 0,
      "eprice" : 0,
      "volume" : 0,
      "idx" : 0
   }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1452OutBlock": {
        "idx": 40
    },
    "t1452OutBlock1": [
        {
            "volume": 2103252,
            "bef_diff": "0000021.02",
            "vol": "000.91",
            "price": 1005,
            "jnilvolume": 10006819,
            "change": 0,
            "shcode": "015590",
            "sign": "3",
            "diff": "000.00",
            "hname": "큐로"
        },
        {
            "volume": 7007,
            "bef_diff": "0000028.27",
            "vol": "000.70",
            "price": 10970,
            "jnilvolume": 24782,
            "change": 0,
            "shcode": "447620",
            "sign": "3",
            "diff": "000.00",
            "hname": "SOL 미국TOP5채권혼합"
        }
    ],
    "rsp_msg": "정상적으로 조회가 완료되었습니다."
}

```

---

## 🏷️ 거래대금상위 (t1463)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                                                                                                                                                                                                                                                                                                                                                  |
|:-------------|:-------------|:-------|:-----------|:---------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| t1463InBlock | t1463InBlock | Object | Y          | -        |                                                                                                                                                                                                                                                                                                                                                              |
| -gubun       | 구분           | String | Y          | 1        | 0 : 전체1 : 코스피2 : 코스닥                                                                                                                                                                                                                                                                                                                                         |
| -jnilgubun   | 전일구분         | String | Y          | 1        | 0 : 당일1 : 전일                                                                                                                                                                                                                                                                                                                                                 |
| -jc_num      | 대상제외         | Number | Y          | 12       | 대상제외값(0x00000080)관리종목  => 000000000128(0x00000100)시장경보  => 000000000256(0x00000200)거래정지  => 000000000512(0x00004000)우선주  => 000000016384(0x00200000)증거금50  => 000008388608(0x01000000)정리매매  => 000016777216(0x04000000)투자유의  => 000067108864(0x80000000)불성실공시  => -02147483648두개 이상 제외시 해당 값을 합산한다예)관리종목 + 시장경보 = 000000000128 + 000000000256 = 000000000384 |
| -sprice      | 시작가격         | Number | Y          | 8        | 현재가 >= sprice                                                                                                                                                                                                                                                                                                                                                |
| -eprice      | 종료가격         | Number | Y          | 8        | 현재가 <= eprice                                                                                                                                                                                                                                                                                                                                                |
| -volume      | 거래량          | Number | Y          | 12       | 거래량 >= volume                                                                                                                                                                                                                                                                                                                                                |
| -idx         | IDX          | Number | Y          | 4        | 처음 조회시는 Space연속 조회시에 이전 조회한 OutBlock의 idx 값으로 설정                                                                                                                                                                                                                                                                                                             |
| -jc_num2     | 대상제외2        | Number | Y          | 12       | 기본         => 000000000000상장지수펀드 => 000000000001선박투자회사 => 000000000002스펙         => 000000000004ETN          => 000000000008(0x00000008)투자주의     => 000000000016(0x00000010)투자위험     => 000000000032(0x00000020)위험예고     => 000000000064(0x00000040)담보불가     => 000000000128(0x00000080)두개 이상 제외시 해당 값을 합산한다.                                                |
| -exchgubun   | 거래소구분코드      | String | Y          | 1        | K: KRXN: NXTU:통합그외 입력값은 KRX로 처리                                                                                                                                                                                                                                                                                                                              |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1463OutBlock  | t1463OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1463OutBlock1 | t1463OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 한글명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -value         | 거래대금           | Number       | Y          | 12       |               |
| -jnilvalue     | 전일거래대금         | Number       | Y          | 12       |               |
| -bef_diff      | 전일비            | Number       | Y          | 10.2     |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -filler        | filler         | String       | Y          | 1        |               |
| -jnilvolume    | 전일거래량          | Number       | Y          | 12       |               |
| -ex_shcode     | 거래소별단축코드       | String       | Y          | 10       |               |
| -total         | 시가총액           | Number       | Y          | 12       |               |


### 💡 Request Example
```json
{
  "t1463InBlock" : {
    "gubun" : "1",
    "jnilgubun" : "1",
    "jc_num" : 0,
    "sprice" : 0,
    "eprice" : 0,
    "volume" : 0,
    "idx" : 0,
    "jc_num2" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1463OutBlock": {
        "idx": 20
    },
    "t1463OutBlock1": [
        {
            "volume": 4817961,
            "bef_diff": "0000039.71",
            "price": 71800,
            "jnilvolume": 12161798,
            "change": 400,
            "jnilvalue": 874631,
            "shcode": "005930",
            "sign": "5",
            "filler": "",
            "diff": "-00.55",
            "value": 347308,
            "hname": "삼성전자"
        },
        {
            "volume": 1087409,
            "bef_diff": "0000121.32",
            "price": 127000,
            "jnilvolume": 923145,
            "change": 3900,
            "jnilvalue": 113286,
            "shcode": "066570",
            "sign": "2",
            "filler": "",
            "diff": "003.17",
            "value": 137441,
            "hname": "LG전자"
        }
    ],
    "rsp_msg": "정상적으로 조회가 완료되었습니다."
}

```

---

## 🏷️ 전일동시간대비거래급증 (t1466)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                                                                                                                                                                                                                                                                                                                                                  |
|:-------------|:-------------|:-------|:-----------|:---------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| t1466InBlock | t1466InBlock | Object | Y          | -        |                                                                                                                                                                                                                                                                                                                                                              |
| -gubun       | 구분           | String | Y          | 1        | 0 : 전체1 : 코스피2 : 코스닥                                                                                                                                                                                                                                                                                                                                         |
| -type1       | 전일거래량        | String | Y          | 1        | 0@1주 이상1@1만주 이상2@5만주 이상3@10만주 이상4@20만주 이상5@50만주 이상6@100만주 이상                                                                                                                                                                                                                                                                                                 |
| -type2       | 거래급등율        | String | Y          | 1        | 0@전체1@2000%이하2@1500%이하3@1000%이하4@500%이하5@100%이하6@50%이하                                                                                                                                                                                                                                                                                                       |
| -jc_num      | 대상제외         | Number | Y          | 12       | 대상제외값(0x00000080)관리종목  => 000000000128(0x00000100)시장경보  => 000000000256(0x00000200)거래정지  => 000000000512(0x00004000)우선주  => 000000016384(0x00200000)증거금50  => 000008388608(0x01000000)정리매매  => 000016777216(0x04000000)투자유의  => 000067108864(0x80000000)불성실공시  => -02147483648두개 이상 제외시 해당 값을 합산한다예)관리종목 + 시장경보 = 000000000128 + 000000000256 = 000000000384 |
| -sprice      | 시작가격         | Number | Y          | 8        | 현재가 >= sprice                                                                                                                                                                                                                                                                                                                                                |
| -eprice      | 종료가격         | Number | Y          | 8        | 현재가 <= eprice                                                                                                                                                                                                                                                                                                                                                |
| -volume      | 거래량          | Number | Y          | 12       | 거래량 >= volume                                                                                                                                                                                                                                                                                                                                                |
| -idx         | IDX          | Number | Y          | 4        | 처음 조회시는 Space연속 조회시에 이전 조회한 OutBlock의 idx 값으로 설정                                                                                                                                                                                                                                                                                                             |
| -jc_num2     | 대상제외2        | Number | Y          | 12       | 기본         => 000000000000상장지수펀드 => 000000000001선박투자회사 => 000000000002스펙         => 000000000004ETN          => 000000000008(0x00000008)투자주의     => 000000000016(0x00000010)투자위험     => 000000000032(0x00000020)위험예고     => 000000000064(0x00000040)담보불가     => 000000000128(0x00000080)두개 이상 제외시 해당 값을 합산한다.                                                |
| -exchgubun   | 거래소구분코드      | String | Y          | 1        | K: KRXN: NXTU:통합그외 입력값은 KRX로 처리                                                                                                                                                                                                                                                                                                                              |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1466OutBlock  | t1466OutBlock  | Object       | Y          | -        |               |
| -hhmm          | 현재시분           | String       | Y          | 5        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1466OutBlock1 | t1466OutBlock1 | Object Array | Y          | -        |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -hname         | 종목명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -stdvolume     | 전일거래량          | Number       | Y          | 12       |               |
| -volume        | 당일거래량          | Number       | Y          | 12       |               |
| -voldiff       | 거래급등율          | Number       | Y          | 8.2      |               |
| -open          | 시가             | Number       | Y          | 8        |               |
| -high          | 고가             | Number       | Y          | 8        |               |
| -low           | 저가             | Number       | Y          | 8        |               |
| -ex_shcode     | 거래소별단축코드       | String       | Y          | 10       |               |


### 💡 Request Example
```json
{
  "t1466InBlock" : {
    "gubun" : "1",
    "type1" : "1",
    "type2" : "1",
    "jc_num" : 0,
    "sprice" : 0,
    "eprice" : 0,
    "volume" : 0,
    "idx" : 0,
    "jc_num2" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1466OutBlock": {
        "hhmm": "10:26",
        "idx": 20
    },
    "rsp_msg": "정상적으로 조회가 완료되었습니다.",
    "t1466OutBlock1": [
        {
            "volume": 20817762,
            "voldiff": "01749.01",
            "high": 145,
            "low": 135,
            "price": 145,
            "shcode": "530036",
            "change": 5,
            "sign": "5",
            "diff": "-3.33",
            "stdvolume": 1190262,
            "hname": "삼성 인버스 2X WTI원",
            "open": 140
        },
        {
            "volume": 953956,
            "voldiff": "00673.56",
            "high": 5890,
            "low": 5550,
            "price": 5610,
            "shcode": "123700",
            "change": 230,
            "sign": "5",
            "diff": "-3.94",
            "stdvolume": 141629,
            "hname": "SJM",
            "open": 5700
        }
    ]
}

```

---

## 🏷️ 시간외등락율상위 (t1481)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description            |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------|
| t1481InBlock | t1481InBlock | Object | Y          | -        |                        |
| -gubun1      | 구분           | String | Y          | 1        | 0:전체                   |
|              |              |        |            |          | 1:코스피                  |
|              |              |        |            |          | 2:코스닥                  |
| -gubun2      | 상승하락         | String | Y          | 1        | 0: 상승률                 |
|              |              |        |            |          | 1: 하락률                 |
| -jongchk     | 종목체크         | String | Y          | 1        | 0: 전체                  |
|              |              |        |            |          | 1: 우선제외                |
|              |              |        |            |          | 2: 관리제외                |
|              |              |        |            |          | 3: 우선관리제외              |
| -volume      | 거래량          | String | Y          | 1        | 0: 전체거래량               |
|              |              |        |            |          | 1: 1천주 이상              |
|              |              |        |            |          | 2: 5천주 이상              |
|              |              |        |            |          | 3: 1만주 이상              |
|              |              |        |            |          | 4: 5만주 이상              |
|              |              |        |            |          | 5: 10만주 이상             |
|              |              |        |            |          | 6: 50만주 이상             |
|              |              |        |            |          | 7: 100만주 이상            |
| -idx         | IDX          | Number | Y          | 4        | 연속조회시 OutBlock의 idx 입력 |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1481OutBlock  | t1481OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1481OutBlock1 | t1481OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 한글명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -offerrem1     | 매도잔량           | Number       | Y          | 12       |               |
| -bidrem1       | 매수잔량           | Number       | Y          | 12       |               |
| -offerho1      | 매도호가           | Number       | Y          | 12       |               |
| -bidho1        | 매수호가           | Number       | Y          | 12       |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -value         | 누적거래대금         | Number       | Y          | 12       |               |


### 💡 Request Example
```json
{
  "t1481InBlock" : {
    "gubun1" : "1",
    "gubun2" : "1",
    "jongchk" : "1",
    "volume" : "1",
    "idx" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1481OutBlock": {
        "idx": 20
    },
    "rsp_msg": "정상적으로 조회가 완료되었습니다.",
    "t1481OutBlock1": [
        {
            "volume": 2136,
            "bidrem1": 301,
            "price": 10490,
            "change": 445,
            "offerrem1": 764,
            "shcode": "449180",
            "sign": "5",
            "diff": "-04.07",
            "bidho1": 10305,
            "value": 22493050,
            "hname": "KODEX 미국S&P500(H)",
            "offerho1": 10485
        },
        {
            "volume": 369875,
            "bidrem1": 9738,
            "price": 935,
            "change": 8,
            "offerrem1": 248,
            "shcode": "031820",
            "sign": "5",
            "diff": "-00.85",
            "bidho1": 935,
            "value": 346240565,
            "hname": "콤텍시스템",
            "offerho1": 936
        }
    ]
}

```

---

## 🏷️ 시간외거래량상위 (t1482)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description                  |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------------|
| t1482InBlock | t1482InBlock | Object | Y          | -        |                              |
| -sort_gbn    | 정렬구분         | Number | Y          | 1        | 0: 거래량1: 거래대금                |
| -gubun       | 구분           | String | Y          | 1        | 0: 전체1: 코스피2: 코스닥            |
| -jongchk     | 거래량          | String | Y          | 1        | 0: 전체1: 우선제외2: 관리제외3: 우선관리제외 |
| -idx         | IDX          | Number | Y          | 4        | 연속조회시 OutBlock의 idx 입력       |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1482OutBlock  | t1482OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1482OutBlock1 | t1482OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 종목명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -vol           | 회전율            | Number       | Y          | 6.2      |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -value         | 누적거래대금         | Number       | Y          | 12       |               |


### 💡 Request Example
```json
{
  "t1482InBlock" : {
    "gubun" : "1",
    "jongchk" : "1",
    "idx" : 0,
    "sort_gbn": 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1482OutBlock1": [
        {
            "volume": 2413264,
            "vol": "000.29",
            "price": 2485,
            "change": 10,
            "shcode": "252670",
            "sign": "5",
            "diff": "-00.40",
            "value": 5998142760,
            "hname": "KODEX 200선물인버스2"
        },
        {
            "volume": 116309,
            "vol": "000.03",
            "price": 1120,
            "change": 5,
            "shcode": "530031",
            "sign": "2",
            "diff": "000.45",
            "value": 130067985,
            "hname": "삼성 레버리지 WTI원？"
        }
    ],
    "rsp_msg": "정상적으로 조회가 완료되었습니다.",
    "t1482OutBlock": {
        "idx": 20
    }
}"

```

---

## 🏷️ 예상체결량상위조회 (t1489)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description            |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------|
| t1489InBlock | t1489InBlock | Object | Y          | -        |                        |
| -gubun       | 거래소구분        | String | Y          | 1        | 0:전체                   |
|              |              |        |            |          | 1:코스피                  |
|              |              |        |            |          | 2:코스닥                  |
| -jgubun      | 장구분          | String | Y          | 1        | 0:장전                   |
|              |              |        |            |          | 1:장후                   |
| -jongchk     | 종목체크         | String | Y          | 12       | 대상제외값(설정시 저장됨)         |
|              |              |        |            |          | 증거금50 : 0x00400000     |
|              |              |        |            |          | 증거금100 : 0x00800000    |
|              |              |        |            |          | 증거금50/100 : 0x00200000 |
|              |              |        |            |          | 관리종목 : 0x00000080      |
|              |              |        |            |          | 시장경보 : 0x00000100      |
|              |              |        |            |          | 거래정지 : 0x00000200      |
|              |              |        |            |          | 우선주 : 0x00004000       |
|              |              |        |            |          | 투자유의 : 0x04000000      |
|              |              |        |            |          | 정리매매 : 0x01000000      |
|              |              |        |            |          | 불성실공시 : 0x80000000     |
| -idx         | IDX          | Number | Y          | 4        | 다음 조회시 사용              |
|              |              |        |            |          | 첫 조회시 Space            |
| -yesprice    | 예상체결시작가격     | Number | Y          | 8        | yesprice <= 예상체결가 인 종목 |
| -yeeprice    | 예상체결종료가격     | Number | Y          | 8        | 예상체결가 <= yeeprice 인 종목 |
| -yevolume    | 예상체결량        | Number | Y          | 12       | 예상체결량 >= yevolume 인 종목 |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1489OutBlock  | t1489OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1489OutBlock1 | t1489OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 한글명            | String       | Y          | 20       |               |
| -price         | 현재가            | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -volume        | 예상거래량          | Number       | Y          | 12       |               |
| -offerho       | 매도호가           | Number       | Y          | 8        |               |
| -bidho         | 매수호가           | Number       | Y          | 8        |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -jnilvolume    | 전일거래량          | Number       | Y          | 12       |               |


### 💡 Request Example
```json
{
  "t1489InBlock" : {
    "gubun" : "1",
    "jgubun" : "1",
    "jongchk" : "1",
    "idx" : 0,
    "yesprice" : 0,
    "yeeprice" : 0,
    "yevolume" : 0
  }
}
```

### 💡 Response Example
```json
{
    "t1489OutBlock1": [
        {
            "volume": 1711086,
            "bidho": 2460,
            "price": 2465,
            "jnilvolume": 94909304,
            "change": 30,
            "shcode": "252670",
            "sign": "5",
            "diff": "-01.20",
            "offerho": 2465,
            "hname": "KODEX 200선물인버스2"
        },
        {
            "volume": 114483,
            "bidho": 896,
            "price": 897,
            "jnilvolume": 125588,
            "change": 106,
            "shcode": "009810",
            "sign": "2",
            "diff": "013.40",
            "offerho": 897,
            "hname": "플레이그램"
        }
    ],
    "rsp_cd": "00000",
    "t1489OutBlock": {
        "idx": 20
    },
    "rsp_msg": "정상적으로 조회가 완료되었습니다."
}

```

---

## 🏷️ 단일가예상등락율상위 (t1492)
### 요청 Header
| Element       | 한글명       | type   | Required   |   Length | Description                                                                     |
|:--------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type  | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| authorization | 접근토큰      | String | Y          |     1000 | OAuth 토큰이 필요한 API 경우 발급한 Access Token을 설정하기 위한 Request Heaeder Parameter        |
| tr_cd         | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont       | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key   | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |
| mac_address   | MAC 주소    | String | Y          |       12 | 법인인 경우 필수 세팅                                                                    |


### 요청 Body
| Element      | 한글명          | type   | Required   | Length   | Description            |
|:-------------|:-------------|:-------|:-----------|:---------|:-----------------------|
| t1492InBlock | t1492InBlock | Object | Y          | -        |                        |
| -gubun1      | 구분           | String | Y          | 1        | 0: 전체                  |
|              |              |        |            |          | 1: 코스피                 |
|              |              |        |            |          | 2: 코스닥                 |
| -gubun2      | 상승하락         | String | Y          | 1        | 0: 상승률                 |
|              |              |        |            |          | 1: 하락률                 |
| -jongchk     | 종목체크         | String | Y          | 1        | 전체@0                   |
|              |              |        |            |          | 우선제외@1                 |
|              |              |        |            |          | 관리제외@2                 |
|              |              |        |            |          | 우선관리제외@3               |
| -volume      | 거래량          | String | Y          | 1        | 전체거래량@0                |
|              |              |        |            |          | 1백주 이상@1               |
|              |              |        |            |          | 5백주 이상@2               |
|              |              |        |            |          | 1천주 이상@3               |
|              |              |        |            |          | 5천주 이상@4               |
|              |              |        |            |          | 1만주 이상@5               |
|              |              |        |            |          | 5만주 이상@6               |
|              |              |        |            |          | 50만주 이상@6              |
|              |              |        |            |          | 100만주 이상@7             |
| -idx         | IDX          | Number | Y          | 4        | 연속조회시 OutBlock의 idx 입력 |


### 응답 Header
| Element      | 한글명       | type   | Required   |   Length | Description                                                                     |
|:-------------|:----------|:-------|:-----------|---------:|:--------------------------------------------------------------------------------|
| content-type | 컨텐츠타입     | String | Y          |      100 | LS증권 제공 API를 호출하기 위한 Request Body 데이터 포맷으로 "application/json; charset=utf-8 설정" |
| tr_cd        | 거래 CD     | String | Y          |       10 | LS증권 거래코드                                                                       |
| tr_cont      | 연속 거래 여부  | String | Y          |        1 | 연속거래 여부Y:연속○N:연속×                                                               |
| tr_cont_key  | 연속 거래 Key | String | Y          |       18 | 연속일 경우 그전에 내려온 연속키 값 올림                                                         |


### 응답 Body
| Element        | 한글명            | type         | Required   | Length   | Description   |
|:---------------|:---------------|:-------------|:-----------|:---------|:--------------|
| t1492OutBlock  | t1492OutBlock  | Object       | Y          | -        |               |
| -idx           | IDX            | Number       | Y          | 4        |               |
| t1492OutBlock1 | t1492OutBlock1 | Object Array | Y          | -        |               |
| -hname         | 한글명            | String       | Y          | 20       |               |
| -price         | 예상체결가          | Number       | Y          | 8        |               |
| -sign          | 전일대비구분         | String       | Y          | 1        |               |
| -change        | 전일대비           | Number       | Y          | 8        |               |
| -diff          | 등락율            | Number       | Y          | 6.2      |               |
| -yevolume      | 예상체결량          | Number       | Y          | 12       |               |
| -volume        | 누적거래량          | Number       | Y          | 12       |               |
| -offerrem1     | 매도잔량           | Number       | Y          | 12       |               |
| -bidrem1       | 매수잔량           | Number       | Y          | 12       |               |
| -offerho1      | 매도호가           | Number       | Y          | 12       |               |
| -bidho1        | 매수호가           | Number       | Y          | 12       |               |
| -shcode        | 종목코드           | String       | Y          | 6        |               |
| -value         | 누적거래대금         | Number       | Y          | 12       |               |


### 💡 Request Example
```json
{
  "t1492InBlock" : {
    "gubun1" : "1",
    "gubun2" : "1",
    "jongchk" : "1",
    "volume" : "1",
    "idx" : 0
  }
}
```

### 💡 Response Example
```json
{
    "rsp_cd": "00000",
    "t1492OutBlock": {
        "idx": 21
    },
    "rsp_msg": "정상적으로 조회가 완료되었습니다.",
    "t1492OutBlock1": [
        {
            "change": -450,
            "offerrem1": 2078,
            "shcode": "005950",
            "sign": "5",
            "yevolume": 24188,
            "diff": "-01.67",
            "volume": 121009,
            "bidrem1": 4015,
            "price": 26550,
            "bidho1": 26500,
            "value": 3226499400,
            "hname": "이수화학",
            "offerho1": 26550
        },
        {
            "change": -60,
            "offerrem1": 1,
            "shcode": "006880",
            "sign": "5",
            "yevolume": 1025,
            "diff": "-00.73",
            "volume": 2840,
            "bidrem1": 122,
            "price": 8180,
            "bidho1": 8180,
            "value": 23213320,
            "hname": "신송홀딩스",
            "offerho1": 8210
        }
    ]
}

```

---
